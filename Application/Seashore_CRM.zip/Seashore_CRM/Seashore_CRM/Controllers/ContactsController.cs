using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using seashore_CRM.DAL.Repositories;
using seashore_CRM.Models.Entities;
using System.Threading.Tasks;
using System.Linq;

namespace Seashore_CRM.Controllers
{
    public class ContactsController : Controller
    {
        private readonly IUnitOfWork _uow;

        public ContactsController(IUnitOfWork uow)
        {
            _uow = uow;
        }

        public async Task<IActionResult> Index()
        {
            var contacts = await _uow.Contacts.GetAllAsync();
            return View(contacts.ToList());
        }

        public async Task<IActionResult> Details(int id)
        {
            var contact = await _uow.Contacts.GetByIdAsync(id);
            if (contact == null) return NotFound();
            return View(contact);
        }

        public async Task<IActionResult> Create()
        {
            var companies = await _uow.Companies.GetAllAsync();
            ViewBag.Companies = new SelectList(companies, "Id", "CompanyName");
            return View(new Contact());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Contact contact)
        {
            if (!ModelState.IsValid)
            {
                var companies = await _uow.Companies.GetAllAsync();
                ViewBag.Companies = new SelectList(companies, "Id", "CompanyName");
                return View(contact);
            }

            await _uow.Contacts.AddAsync(contact);
            await _uow.CommitAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int id)
        {
            var contact = await _uow.Contacts.GetByIdAsync(id);
            if (contact == null) return NotFound();
            var companies = await _uow.Companies.GetAllAsync();
            ViewBag.Companies = new SelectList(companies, "Id", "CompanyName", contact.CompanyId);
            return View(contact);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Contact contact)
        {
            if (id != contact.Id) return BadRequest();
            if (!ModelState.IsValid)
            {
                var companies = await _uow.Companies.GetAllAsync();
                ViewBag.Companies = new SelectList(companies, "Id", "CompanyName", contact.CompanyId);
                return View(contact);
            }
            _uow.Contacts.Update(contact);
            await _uow.CommitAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int id)
        {
            var contact = await _uow.Contacts.GetByIdAsync(id);
            if (contact == null) return NotFound();
            return View(contact);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var contact = await _uow.Contacts.GetByIdAsync(id);
            if (contact != null)
            {
                _uow.Contacts.Remove(contact);
                await _uow.CommitAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}