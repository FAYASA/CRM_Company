using seashore_CRM.Models.Entities;

namespace seashore_CRM.DAL.Repositories
{
    public interface ILeadRepository : IRepository<Lead>
    {
        // Define Lead-specific methods here, for example:
        // Task<IEnumerable<Lead>> GetByStatusAsync(int statusId);
    }
}
