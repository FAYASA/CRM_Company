using System.Threading.Tasks;
using seashore_CRM.DAL.Data;
using seashore_CRM.Models.Entities;

namespace seashore_CRM.DAL.Repositories
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly AppDbContext _context;

        public UnitOfWork(AppDbContext context)
        {
            _context = context;
            Users = new Repository<User>(_context);
            Roles = new Repository<Role>(_context);
            Companies = new CompanyRepository(_context);
            Contacts = new ContactRepository(_context);
            Leads = new LeadRepository(_context);
            LeadStatuses = new Repository<LeadStatus>(_context);
            LeadSources = new Repository<LeadSource>(_context);
            Opportunities = new Repository<Opportunity>(_context);
            Categories = new Repository<Category>(_context);
            Products = new ProductRepository(_context);
            Sales = new SaleRepository(_context);
            SaleItems = new Repository<SaleItem>(_context);
            Invoices = new InvoiceRepository(_context);
            Payments = new Repository<Payment>(_context);
            Activities = new Repository<Activity>(_context);
            Comments = new CommentRepository(_context);
            LeadItems = new Repository<LeadItem>(_context);
        }

        public IRepository<User> Users { get; }
        public IRepository<Role> Roles { get; }
        public ICompanyRepository Companies { get; }
        public IContactRepository Contacts { get; }
        public ILeadRepository Leads { get; }
        public IRepository<LeadStatus> LeadStatuses { get; }
        public IRepository<LeadSource> LeadSources { get; }
        public IRepository<Opportunity> Opportunities { get; }
        public IRepository<Category> Categories { get; }
        public IProductRepository Products { get; }
        public ISaleRepository Sales { get; }
        public IRepository<SaleItem> SaleItems { get; }
        public IInvoiceRepository Invoices { get; }
        public IRepository<Payment> Payments { get; }
        public IRepository<Activity> Activities { get; }
        public ICommentRepository Comments { get; }
        public IRepository<LeadItem> LeadItems { get; }

        public async Task<int> CommitAsync()
        {
            return await _context.SaveChangesAsync();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
