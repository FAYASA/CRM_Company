using seashore_CRM.Models.Entities;

namespace seashore_CRM.DAL.Repositories
{
    public interface ICompanyRepository : IRepository<Company>
    {
        // Add company-specific methods here
    }
}
