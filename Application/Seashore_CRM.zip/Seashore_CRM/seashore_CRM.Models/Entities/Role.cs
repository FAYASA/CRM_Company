namespace seashore_CRM.Models.Entities
{
    public class Role : BaseEntity
    {
        public string RoleName { get; set; } = null!;
    }
}
