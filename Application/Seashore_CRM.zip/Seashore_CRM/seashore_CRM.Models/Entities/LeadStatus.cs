namespace seashore_CRM.Models.Entities
{
    public class LeadStatus : BaseEntity
    {
        public string StatusName { get; set; } = null!;
    }
}
