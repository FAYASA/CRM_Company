namespace seashore_CRM.Models.Entities
{
    public class Category : BaseEntity
    {
        public string CategoryName { get; set; } = null!;
    }
}
