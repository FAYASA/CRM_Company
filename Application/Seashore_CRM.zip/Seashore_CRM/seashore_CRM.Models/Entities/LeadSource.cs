namespace seashore_CRM.Models.Entities
{
    public class LeadSource : BaseEntity
    {
        public string SourceName { get; set; } = null!;
    }
}
